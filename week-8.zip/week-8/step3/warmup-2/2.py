def front_times(str, n):
  if len(str)>2:
    return str[0:3]*n
  else:
    return str*n
