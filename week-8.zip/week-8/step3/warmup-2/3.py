def string_bits(str):
  return str[0::2]
