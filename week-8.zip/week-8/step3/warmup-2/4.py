def string_splosion(str):
  s = ""
  for i in range(len(str)):
    s+=str[0:i+1]
  return s
      
