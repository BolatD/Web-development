def first_two(str):
  if len(str)>=2:
    return str[0:2]
  else:
    return str
