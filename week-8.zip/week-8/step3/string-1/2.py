def make_abba(a, b):
  return a+b+b+a
