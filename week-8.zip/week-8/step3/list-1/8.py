def max_end3(nums):
  x = max(nums[0],nums[-1])
  ll = [x,x,x]
  return ll
