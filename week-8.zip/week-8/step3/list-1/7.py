def reverse3(nums):
  return nums[-1::-1]
