def make_ends(nums):
  ll = [nums[0],nums[-1]]
  return ll
