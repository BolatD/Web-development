def sum3(nums):
  return nums[0]+nums[1]+nums[2]
