def double_char(str):
  s = ''
  for i in str:
    s+=(i*2)
  return s
