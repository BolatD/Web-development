def sleep_in(weekday, vacation):
  if weekday==False:
    return True
  elif vacation==True:
    return True
  else:
    return False
