b= input().split()

def mini(a,b,c,d):
   e= min(a,b)
   f= min(c,d)
   e=min(e,f)
   return e

print(mini(b[0],b[1],b[2],b[3]))
