a=int(input())

c=a+1
d=a-1
print("The next number for the number"+ " "+str(a) + " " +"is"+ " "+str(c) + ".")
print("The previous number for the number"+ " "+ str(a) + " " + "is"+ " " + str(d) + ".")