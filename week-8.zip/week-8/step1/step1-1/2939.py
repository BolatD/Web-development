a=int(input())
b=int(input())

c=b%a

print(c)