import math

a=int(input())
b=int(input())
c=math.sqrt(b*b+a*a)
print(c)  