n = int(input())
if n & (n - 1) :
    print("NO")
else:
    print("YES")
