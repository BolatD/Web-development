n=int(input())
power=1

while power<= n:
	print(power, end=" ")
	power *=2
	
	
	


 
