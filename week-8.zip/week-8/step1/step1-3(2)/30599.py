def power_of_two(n):
sqr=1
while(sqr<=n):
	print(sqr,end=" ")
	sqr=sqr*2

