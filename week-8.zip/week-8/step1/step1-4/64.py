a=int(input())
b=input().split()
for b in range(1,a):
	if b%2==0:
		print(b, end=" ")