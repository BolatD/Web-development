a=int(input())
b=input().split()
c=0
for b in range(1,a):
	if b>0:
		c+=1
		print(c)

