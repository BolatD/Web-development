a=int(input())
b=input().split()
for i in range(0,a):
	if i%2==0:
		print(int(b[i]), end=" ")