x=int(input())
if x>0:
	print(1)
if x<0:
    print(-1)
if x==0:
	print(0)


    
 
