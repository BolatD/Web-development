a = int(input())
#i = 2
#while a % i != 0:  
   # i += 1
#print(i)
for i in range(2,a+1):
	if a%i==0:
		print(i)
	break