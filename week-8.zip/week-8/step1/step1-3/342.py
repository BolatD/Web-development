sum=0;
for x in range(0,100):
	sum+= int(input())

print(sum)