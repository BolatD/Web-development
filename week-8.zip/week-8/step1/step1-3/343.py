a=int(input())
sum=0
for i in range(a):
	sum+=int(input())

print(sum)	
