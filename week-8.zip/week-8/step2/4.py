a=int(input())
b=int(input())
c=a//b
d=a/b
print(c)
print(d)