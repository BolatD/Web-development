mystr="Hello,World!"
print(mystr)