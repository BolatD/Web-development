n=int(input())
for i in range(n):
	if i<n:
		print(i**2)
