n=int(input())
for x in range(n):
    print(x + 1,end ="")