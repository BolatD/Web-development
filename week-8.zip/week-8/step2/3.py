a=int(input())
b=int(input())
c=a+b
d=a-b
l=a*b
print(str(c))
print(str(d))
print(str(l))